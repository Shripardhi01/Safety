package com.dynast.womensafety;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.dynast.womensafety.helper.SharedPrefManager;

import java.util.ArrayList;

public class BuzzerPage extends AppCompatActivity implements LocationListener {

    Button btn_safe, btnHelp, btnLogOut;
    private ArrayList permissionsToRequest;
    private ArrayList permissionsRejected = new ArrayList();
    private ArrayList permissions = new ArrayList();
    LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buzzer_page);

        btn_safe = findViewById(R.id.btnsafe);
        btnHelp = findViewById(R.id.btnhelp);
        btnLogOut = findViewById(R.id.btnout);

        final String name = SharedPrefManager.getInstance(getApplicationContext()).getUser().getName();
        final String mobile = SharedPrefManager.getInstance(getApplicationContext()).getUser().getMobile();
        final String address = SharedPrefManager.getInstance(getApplicationContext()).getUser().getAddress();
        final String mob1 = SharedPrefManager.getInstance(getApplicationContext()).getUser().getEm1();
        final String mob2 = SharedPrefManager.getInstance(getApplicationContext()).getUser().getEm2();
        final String mob3 = SharedPrefManager.getInstance(getApplicationContext()).getUser().getEm3();

        String message = "";


        btnHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getLocation();
            }
        });

    }

    private void getLocation() {
        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5, (LocationListener) this);
        }
        catch(SecurityException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        Toast.makeText(this,"Current Location: " + location.getLatitude() + ", " + location.getLongitude(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {
        Toast.makeText(this, "Please Enable GPS and Internet", Toast.LENGTH_SHORT).show();
    }
}

